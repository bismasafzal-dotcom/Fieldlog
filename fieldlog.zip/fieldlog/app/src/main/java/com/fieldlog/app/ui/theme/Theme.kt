package com.fieldlog.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The palette comes off a job site, not off a design template:
 * steel-black ink, chalk-grey paper, and safety hi-vis amber as the one loud colour.
 * Sunlight is the enemy here, so everything is maximum contrast and flat — no
 * shadows, no gradients, no translucency. That also renders fast on a cheap phone.
 */
val Ink = Color(0xFF14171A)          // steel black — text and the clocked-out slab
val Chalk = Color(0xFFF4F5F2)        // cool grey-white — the page
val Card = Color(0xFFFFFFFF)
val HiVis = Color(0xFFFFC300)        // safety amber — CLOCK IN. The one loud thing.
val Running = Color(0xFF1E7A46)      // deep green — on the clock
val Steel = Color(0xFF5A6672)        // muted grey-blue — labels, secondary text
val Hairline = Color(0xFFDBDDD8)     // 1dp borders instead of drop shadows
val Flag = Color(0xFFD93025)         // red — money going out, destructive actions

private val LightColors = lightColorScheme(
    primary = Ink,
    onPrimary = Chalk,
    secondary = HiVis,
    onSecondary = Ink,
    tertiary = Running,
    onTertiary = Color.White,
    background = Chalk,
    onBackground = Ink,
    surface = Card,
    onSurface = Ink,
    surfaceVariant = Chalk,
    onSurfaceVariant = Steel,
    outline = Hairline,
    error = Flag,
    onError = Color.White
)

// Night shift is real. Same logic, inverted, still flat.
private val DarkColors = darkColorScheme(
    primary = HiVis,
    onPrimary = Ink,
    secondary = HiVis,
    onSecondary = Ink,
    tertiary = Color(0xFF33B06A),
    onTertiary = Ink,
    background = Color(0xFF0E1013),
    onBackground = Color(0xFFECEDE9),
    surface = Color(0xFF191D21),
    onSurface = Color(0xFFECEDE9),
    surfaceVariant = Color(0xFF191D21),
    onSurfaceVariant = Color(0xFF9AA5AE),
    outline = Color(0xFF2E353B),
    error = Color(0xFFFF6B5E),
    onError = Ink
)

/**
 * Numbers are the content of this app — hours, money, a running clock. So the numerals
 * get the characterful face (monospace, like a meter or a printed work docket) and the
 * prose gets out of the way. Monospace also means the timer digits don't jitter as they tick.
 * Both faces ship with Android, so the app stays tiny and needs no download to look right.
 */
val Meter = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Bold,
    letterSpacing = (-1).sp
)

/** Small all-caps labels, like the headings printed on a paper timesheet. */
val Docket = TextStyle(
    fontFamily = FontFamily.SansSerif,
    fontWeight = FontWeight.Bold,
    fontSize = 12.sp,
    letterSpacing = 1.2.sp
)

private val AppTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Black,
        fontSize = 30.sp,
        letterSpacing = (-0.5).sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 17.sp   // bumped up: this gets read at arm's length, outdoors
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 15.sp
    ),
    labelSmall = Docket
)

/** Minimum size for anything tappable. Assume gloves. Assume a bumpy van. */
val TapTarget = 64.dp

@Composable
fun FieldLogTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
