package com.fieldlog.app

import android.app.Application
import com.fieldlog.app.data.Entitlement

class FieldLogApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Records the install date on the very first launch, once, forever.
        // Costs nothing, uses no network, and is the only way to be fair to early
        // users if this app ever starts charging. See data/Entitlement.kt.
        Entitlement.ensureStamped(this)
    }
}
