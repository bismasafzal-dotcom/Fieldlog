package com.fieldlog.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.fieldlog.app.ui.AppScaffold
import com.fieldlog.app.ui.theme.FieldLogTheme

/**
 * The single screen the operating system launches. Everything else is drawn
 * inside it by Compose. There is no network code anywhere in this app —
 * it has no INTERNET permission, so it physically cannot phone home.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            FieldLogTheme {
                AppScaffold()
            }
        }
    }
}
